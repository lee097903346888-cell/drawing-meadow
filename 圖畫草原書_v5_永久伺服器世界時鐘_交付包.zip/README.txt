圖畫草原書 v5｜永久伺服器世界時鐘

這版不再由「房主瀏覽器」替世界計時。

運作方式：
- Supabase 儲存世界時間錨點。
- PostgreSQL 伺服器用自己的 clock_timestamp() 算出現在的世界絕對時間。
- 所有人每 15 秒校時一次；中間只在手機本機平滑顯示。
- 所有人都離線時，不需要任何網頁保持開啟；下次有人回來會直接算到正確的世界時間。
- 切回 Safari / Chrome 頁面時會立即重新向伺服器校時。
- 自動天氣改為由「世界日 + 世界ID」決定，因此所有玩家一致，也不需要房主在線換天氣。
- 早餐 / 午餐 / 晚餐仍使用既有 process_meal RPC。只要有任一玩家在線並處於用餐時段，就會用世界日+餐別的唯一鍵嘗試處理，避免重複成長。
- 這次「永久」指世界時間本身：即使所有人離線，日期與時刻仍持續前進。若要連『離線期間每一餐都自動成長/消耗食物』也完全伺服器化，還需要再把 process_meal 的資料庫邏輯改成伺服器排程。

第一次升級必做：
1. 進 Supabase Dashboard。
2. 開 SQL Editor。
3. 把 supabase_world_clock_v5.sql 全部貼上並 Run 一次。
4. 再把 index.html 上傳 GitHub，覆蓋舊版 index.html。
5. 重新整理 GitHub Pages。

重要：
- 只換 HTML、不執行 SQL，會看到「function get_world_clock does not exist」。
- 不需要 pg_cron，也不需要任何一台手機永遠開著。
- 這個版本保留：單一共同世界、連續草原、相簿/拍照、滿螢幕、角色動畫、去背、成長與多人 Realtime。
