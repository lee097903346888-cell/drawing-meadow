-- 圖畫草原書 v5：永久伺服器世界時鐘
-- 請在 Supabase Dashboard -> SQL Editor 執行一次。
-- 不需要 pg_cron；時間是由 PostgreSQL 的 now()/clock_timestamp() + 錨點即時計算，
-- 因此即使完全沒有玩家在線，世界時間仍然持續前進。

begin;

alter table public.rooms
  add column if not exists world_clock_anchor_at timestamptz,
  add column if not exists world_clock_anchor_hours double precision;

-- 把既有房間目前的世界日/時間轉成「絕對世界小時」。
update public.rooms
set
  world_clock_anchor_hours =
    coalesce(world_clock_anchor_hours,
      greatest(0,
        (greatest(1,coalesce(world_day,1))-1)*24
        + coalesce(world_time,9)
      )
    ),
  world_clock_anchor_at = coalesce(world_clock_anchor_at, now());

alter table public.rooms
  alter column world_clock_anchor_at set default now(),
  alter column world_clock_anchor_at set not null,
  alter column world_clock_anchor_hours set default 9,
  alter column world_clock_anchor_hours set not null;

-- 任何已登入（包含 Supabase Anonymous Sign-In）玩家都可讀取世界時鐘。
create or replace function public.get_world_clock(p_room_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  r public.rooms%rowtype;
  v_now timestamptz := clock_timestamp();
  v_day_minutes double precision;
  v_speed double precision;
  v_abs double precision;
  v_day integer;
  v_hour double precision;
begin
  select * into r
  from public.rooms
  where id = p_room_id;

  if not found then
    raise exception 'ROOM_NOT_FOUND';
  end if;

  v_day_minutes :=
    greatest(1,
      coalesce(
        nullif(r.settings->>'day_minutes','')::double precision,
        8
      )
    );

  v_speed :=
    greatest(.05,
      coalesce(
        nullif(r.settings->>'world_speed','')::double precision,
        1
      )
    );

  v_abs :=
    greatest(0,
      r.world_clock_anchor_hours
      + extract(epoch from (v_now-r.world_clock_anchor_at))
        * (24.0/(v_day_minutes*60.0))
        * v_speed
    );

  v_day := floor(v_abs/24.0)::integer + 1;
  v_hour := v_abs - floor(v_abs/24.0)*24.0;

  return jsonb_build_object(
    'server_now', v_now,
    'abs_hours', v_abs,
    'day', v_day,
    'hour', v_hour,
    'anchor_at', r.world_clock_anchor_at,
    'anchor_hours', r.world_clock_anchor_hours
  );
end;
$$;

grant execute on function public.get_world_clock(uuid) to authenticated;

-- 管理者改「一天幾分鐘 / 世界速度」時，
-- 必須先按舊速度算到伺服器當下，再把當下位置設成新錨點，
-- 否則修改速度會讓整個歷史時間跳動。
create or replace function public.update_world_settings(
  p_room_id uuid,
  p_settings jsonb,
  p_weather text,
  p_upload_enabled boolean
)
returns jsonb
language plpgsql
security invoker
set search_path = public
as $$
declare
  r public.rooms%rowtype;
  v_now timestamptz := clock_timestamp();
  v_day_minutes double precision;
  v_speed double precision;
  v_abs double precision;
  v_day integer;
  v_hour double precision;
begin
  select * into r
  from public.rooms
  where id=p_room_id
  for update;

  if not found then
    raise exception 'ROOM_NOT_FOUND';
  end if;

  v_day_minutes :=
    greatest(1,
      coalesce(nullif(r.settings->>'day_minutes','')::double precision,8)
    );
  v_speed :=
    greatest(.05,
      coalesce(nullif(r.settings->>'world_speed','')::double precision,1)
    );

  v_abs :=
    greatest(0,
      r.world_clock_anchor_hours
      + extract(epoch from (v_now-r.world_clock_anchor_at))
        * (24.0/(v_day_minutes*60.0))
        * v_speed
    );

  v_day := floor(v_abs/24.0)::integer+1;
  v_hour := v_abs - floor(v_abs/24.0)*24.0;

  update public.rooms
  set
    world_clock_anchor_at=v_now,
    world_clock_anchor_hours=v_abs,
    world_time=v_hour,
    world_day=v_day,
    settings=p_settings,
    weather=p_weather,
    upload_enabled=p_upload_enabled,
    locked=false
  where id=p_room_id
  returning * into r;

  if not found then
    raise exception 'NOT_ALLOWED';
  end if;

  return to_jsonb(r);
end;
$$;

grant execute on function public.update_world_settings(uuid,jsonb,text,boolean) to authenticated;

-- 後台「白天 / 夜晚 / 早餐 / 午餐 / 晚餐」快速跳時。
-- SECURITY INVOKER：沿用你原本 rooms UPDATE 的 RLS，因此只有原本可修改房間的人能成功。
create or replace function public.set_world_clock_hour(
  p_room_id uuid,
  p_hour double precision
)
returns jsonb
language plpgsql
security invoker
set search_path = public
as $$
declare
  r public.rooms%rowtype;
  v_now timestamptz := clock_timestamp();
  v_day_minutes double precision;
  v_speed double precision;
  v_abs_now double precision;
  v_day_index bigint;
  v_new_abs double precision;
begin
  select * into r
  from public.rooms
  where id=p_room_id
  for update;

  if not found then
    raise exception 'ROOM_NOT_FOUND';
  end if;

  v_day_minutes :=
    greatest(1,
      coalesce(nullif(r.settings->>'day_minutes','')::double precision,8)
    );
  v_speed :=
    greatest(.05,
      coalesce(nullif(r.settings->>'world_speed','')::double precision,1)
    );

  v_abs_now :=
    greatest(0,
      r.world_clock_anchor_hours
      + extract(epoch from (v_now-r.world_clock_anchor_at))
        * (24.0/(v_day_minutes*60.0))
        * v_speed
    );

  v_day_index := floor(v_abs_now/24.0)::bigint;
  v_new_abs := v_day_index*24.0 + greatest(0,least(23.9999,p_hour));

  update public.rooms
  set
    world_clock_anchor_at=v_now,
    world_clock_anchor_hours=v_new_abs,
    world_time=v_new_abs - floor(v_new_abs/24.0)*24.0,
    world_day=floor(v_new_abs/24.0)::integer+1
  where id=p_room_id
  returning * into r;

  if not found then
    raise exception 'NOT_ALLOWED';
  end if;

  return to_jsonb(r);
end;
$$;

grant execute on function public.set_world_clock_hour(uuid,double precision) to authenticated;

commit;
